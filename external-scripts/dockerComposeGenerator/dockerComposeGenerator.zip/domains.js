module.exports = {
	version: "0.82.1",
	host: "example.com",
	domains: {
	    makiland: [40100, "admin:password"],
	    foxshrine: [40120, "admin:password"],
	}
};